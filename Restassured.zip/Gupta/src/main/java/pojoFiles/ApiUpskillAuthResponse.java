package pojoFiles;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ApiUpskillAuthResponse {
	@JsonProperty
	int success;
	@JsonProperty
	List<ApiUpskillError> error;
	@JsonProperty 
	ApiUpskillToken data;
	
	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}
	
	public List<ApiUpskillError> getError() {
		return error;
	}
	public void setError(List<ApiUpskillError> error) {
		this.error = error;
	}
	public ApiUpskillToken getData() {
		return data;
	}
	public void setData(ApiUpskillToken data) {
		this.data = data;
	}
	

}
