package pojoFiles;

public class ApiUpskillError {

}
