package Day4;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;


public class Action {

		public static void main(String[] args) throws InterruptedException {
			// Launching edge
			System.setProperty("webdriver.edge.driver",
					"C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
			WebDriver wd = new EdgeDriver();
			wd.manage().window().maximize();
			Thread.sleep(2000);
			// Navigating to URL
			wd.get("https://www.google.com/");
			Thread.sleep(2000);
			WebElement inputSerachBox = wd.findElement(By.name("q"));
			Actions action=new  Actions(wd);
			action.keyDown(inputSerachBox,Keys.SHIFT);
			action.sendKeys(inputSerachBox,"SELenium");
			action.keyUp(inputSerachBox,Keys.SHIFT);
			action.build().perform();
	        //Double click
			//action.doubleClick();
			//action.sendKeys(inputSerachBox,Keys.SHIFT)
	        //CTRL+C
	        Thread.sleep(2000);
	        Robot rbt;
			try {
				rbt = new Robot();
				rbt.keyPress(KeyEvent.VK_6);
			} catch (AWTException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Thread.sleep(2000);
			System.out.println("End");
			wd.close();
		}
}