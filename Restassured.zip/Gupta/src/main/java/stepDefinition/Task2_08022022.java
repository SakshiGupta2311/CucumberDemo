package stepDefinition;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Task2_08022022 {

	Response res;
	RequestSpecification httpReq; 
	String BASE_URL="https://reqres.in/";

	@Given("Get List of user API")
	public void get_list_of_user_api() {
		System.out.println("Get user lists");
		
	}

	@When("Provide different values to page number {int}")
	public void provide_different_values_to_page_number(Integer int1) {
		System.out.println("Current page no:" +int1);
		RestAssured.baseURI=BASE_URL;
		httpReq=RestAssured.given().header("Content-Type","application/json");
        //res=httpReq.request(Method.GET);
     	res= httpReq.get("api/users?page="+int1);
        }

	@Then("Status_code equals {int}")
	public void status_code_equals(Integer int1) {
		System.out.println("Stauscode is:"+res.getStatusCode());
		assertEquals(res.getStatusCode(), +int1);
		}

	@Then("response contains valid data")
	public void response_contains_valid_data() {
		res.getBody().prettyPrint();
	}

	@Given("Post Api for adding new user")
	public void post_api_for_adding_new_user() {
		System.out.println("Post new User");
	 	}

	@When("Username: {string} and Job: {string}")
	public void username_and_job(String string, String string2) {
	   	RestAssured.baseURI=BASE_URL;
		String requestBody="{\"name\" : \"{{FIRST_NAME}}\",\"job\" : \"{{UPDATED_JOB}}\"}";
		requestBody=requestBody.replace("{{FIRST_NAME}}", string);
		requestBody=requestBody.replace("{{UPDATED_JOB}}", string2);
		System.out.println("Request Payload:" +requestBody);
		Header acceptHeader = new Header("Content-Type","application/json");
        httpReq=RestAssured.given().header(acceptHeader).body(requestBody);
     	res= httpReq.post("api/users");
	}
	
	@Given("Put Api for updating existing user")
	public void put_api_for_updating_existing_user() {
		System.out.println("Updating existing users");
	}

	@When("Updating Userid: {int} with username: {string} and Job: {string}")
	public void updating_userid_with_username_and_job(Integer int1, String string, String string2) {
	 	RestAssured.baseURI=BASE_URL;
		String requestBody="{\"name\" : \"{{FIRST_NAME}}\",\"job\" : \"{{JOB}}\"}";
		requestBody=requestBody.replace("{{FIRST_NAME}}", string);
		requestBody=requestBody.replace("{{JOB}}", string2);
		System.out.println("Request Payload:" +requestBody);
		Header acceptHeader = new Header("Content-Type","application/json");
        httpReq=RestAssured.given().header(acceptHeader).body(requestBody);
     	res= httpReq.put("api/users/"+int1);
	}
	
	@Given("Delete Api for deleting user")
	public void delete_api_for_deleting_user() {
		System.out.println("Deleting existing user");
	}

	@When("UserID to be deleted: {int}")
	public void user_id_to_be_deleted(Integer int1) {
	 	RestAssured.baseURI=BASE_URL;
		Header acceptHeader = new Header("Content-Type","application/json");
        httpReq=RestAssured.given().header(acceptHeader);
        System.out.println("User id: "+int1);
     	res= httpReq.delete("api/users"+int1);
	}


}
