package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Project1_24012021 {
	
	WebDriver wd;
		
	@Given("Open Google URL")
	public void open_google_url() throws InterruptedException {
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
	    wd=new EdgeDriver();
	    wd.manage().window().maximize();
		//Navigating to google
		wd.get("https://www.google.com/");
		Thread.sleep(2000);
	}

	@When("I search the text {string}")
	public void i_search_the_text_(String string) throws InterruptedException {
	    System.out.println("I am inside google search page");
	    //Enter text and search
		wd.findElement(By.name("q")).sendKeys(string + Keys.ENTER);
		Thread.sleep(2000);
		}

	@Then("I click on the first link available")
	public void i_click_on_the_first_link_available() throws InterruptedException {
	    //Click on 1st link
		System.out.println("First Link is:" + wd.findElement(By.xpath("(//a/h3)[1]")).getText());
		wd.findElement(By.xpath("(//a/h3)[1]")).click();
		Thread.sleep(5000);
		wd.close();
		}

}
