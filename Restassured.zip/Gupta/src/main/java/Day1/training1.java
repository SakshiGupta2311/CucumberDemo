package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class training1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//Launching Edge
		System.setProperty("webdriver.edge.driver", "C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
		WebDriver wd=new EdgeDriver();
		//Navigating to google
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		// Extracting Navigated URL
		System.out.println("URL:" + wd.getCurrentUrl());
		// Extracting Title
		System.out.println("TITLE:" + wd.getTitle());
		wd.findElement(By.name("q")).sendKeys("Selenium is good"+Keys.ENTER);
		//Thread.sleep(5000);
		//wd.findElement(By.name("btnK")).click();
		Thread.sleep(3000);
		wd.navigate().to("https://in.search.yahoo.com/?fr2=inr");
		Thread.sleep(5000);
		wd.navigate().back();
		Thread.sleep(5000);
		wd.navigate().forward();
		Thread.sleep(3000);
		wd.navigate().refresh();
		
		// Closing Chrome
		wd.close();

	}

}
