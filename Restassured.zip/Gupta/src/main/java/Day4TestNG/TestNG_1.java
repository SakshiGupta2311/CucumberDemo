package Day4TestNG;

import org.testng.annotations.Test;

public class TestNG_1 {
	//priority-default then priority ,orders, if not given then priority by alphabet
  @Test(dependsOnMethods="secondTestNGmethod")
	public void firstTestNGmethod()
	{
	  System.out.println("Hello testNG first");
	}
   @Test
	public void secondTestNGmethod()
	{
	  System.out.println("Hello testNG second");
	}
   @Test(priority = 1)
	public void thirdTestNGmethod()
	{
	  System.out.println("Hello testNG third");
	}
}
