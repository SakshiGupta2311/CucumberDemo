package log4j;

public class Log4jDemo {
	/*
	//To specify Properties location for log4j
		PropertyConfigurator.configure("C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\src\\log4j.properties");
		//Creating instance of logger
		Logger log=Logger.getLogger("devpinoyLogger");
		System.out.println("Hello Log4J");
		log.info("Hello Log4J from Logger as info");
		log.debug("Hello Log4J from Logger as Debug");
*/
}
