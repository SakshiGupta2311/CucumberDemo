package restAssuredDemo;

import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class ImgurDemo {
	@Test
	public void oAuthDemo(){
		Response resp=RestAssured.given()
				.baseUri("https://api.imgur.com/3/account/me/images")
				.accept(ContentType.JSON)
				.header("Authorization","Bearer b9fd159658422f70a7cb16dc7f919ec58734ffe7")
		.when()
			.get();
			resp.prettyPrint();
		  
	}
}
