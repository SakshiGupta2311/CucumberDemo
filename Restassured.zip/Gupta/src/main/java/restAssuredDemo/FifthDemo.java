package restAssuredDemo;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FifthDemo {
		
		@Test
		public void restDemo() {
			/*System.out.println("Inside Rest");
			//File handling
			File jsonFile=new File("C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\src\\main\\java\\restAssuredDemo\\AuthPayLoad.json");
			////==================Approach 1====================
			//1. Base URI
			RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
			//2. Request Specification
			Header acceptHeader = new Header("Content-Type","application/json");
	        RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(jsonFile);
			Response res=httpReq.request(Method.POST);
			res.getBody().prettyPrint();*/
					
			
			System.out.println("Inside Rest");
			//File handling
			File xmlFile=new File("C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\src\\main\\java\\restAssuredDemo\\AuthPayLoad.xml");
			////==================Approach 1====================
			//1. Base URI
			RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
			//2. Request Specification
			Header acceptHeader1 = new Header("Content-Type","application/xml");
	        RequestSpecification httpReq1=RestAssured.given().header(acceptHeader1).body(xmlFile);
			Response res1=httpReq1.request(Method.POST);
			System.out.println(res1.getStatusCode());
			res1.getBody().prettyPrint();
		}
	}
