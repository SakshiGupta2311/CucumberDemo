package restAssuredDemo;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pojoFiles.BookingResponse;

public class FourthRestAssuredDemo2 {
	@Test
	public void restDemo() {
	
		System.out.println("Inside Rest");
		//1. Base URI
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking/1";
		//2. Request Specification
        RequestSpecification httpReq=RestAssured.given();
		Response res=httpReq.request(Method.GET);
		//3. Reading Reponse--Parsing Repsonse
		BookingResponse bookingResponse=res.as(BookingResponse.class);
	//	BookingDates bookingDates=res.as(BookingDates.class);---no need
		//De-Serialization PLAIN TEXT>> JAVA OBject
		System.out.println("FiRST NAME="+bookingResponse.getFirstname());
		System.out.println("Last NAME="+bookingResponse.getLastname());
		System.out.println("Total Price="+bookingResponse.getTotalprice());
	System.out.println("Booking CheckinDate="+bookingResponse.getBookingdates().getCheckin());
	System.out.println("Booking CheckoutDate="+bookingResponse.getBookingdates().getCheckout());
	System.out.println("Additional Needs="+bookingResponse.getAdditionalneeds());
		System.out.println("Deposit Paid="+bookingResponse.isDepositpaid());
//		System.out.println(bookingResponse.getLastname());
	//	assertEquals("Eric",bookingResponse.getFirstname());
	}

	}

