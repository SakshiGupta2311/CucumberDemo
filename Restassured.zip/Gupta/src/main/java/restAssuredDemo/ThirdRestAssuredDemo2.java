package restAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ThirdRestAssuredDemo2 {
	
	@Test
	public void restDemo() {
	RestAssured.baseURI="https://restful-booker.herokuapp.com/booking/2";
	//Header acceptHeader = new Header("accept","text/plain");
    //RequestSpecification httpReq1=RestAssured.given().header(acceptHeader);
	RequestSpecification httpReq1=RestAssured.given();
	Response res1=httpReq1.request(Method.GET);
	String respBody1=res1.getBody().asString();
	System.out.println(respBody1);
	
	}
}
