package restAssuredDemo;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class getTokenDirect {
	
		@Test
		public void restDemo() {
			System.out.println("Inside Rest");
			/*//1. Base URI
			RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
			String requestBody = "{\n" +
		            "  \"username\" : \"admin\",\n" +
		            "  \"password\" : \"password123\"\n" +
		       "}";
			//String jsonFile="{\"username\" : \"admin\",\"password\" : \"password123\"}";
			//2. Request Specification
			Header acceptHeader = new Header("Content-Type","application/json");
	        RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(requestBody);
			Response res=httpReq.request(Method.POST);
			res.getBody().prettyPrint();*/
			
			RestAssured.baseURI="https://reqres.in/";
			String requestBody = "{\n" +
		            "  \"name\" : \"Sakshi\",\n" +
		            "  \"job\" : \"Tester\"\n" +
		       "}";
			Header acceptHeader = new Header("Content-Type","application/json");
			RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(requestBody);
	        //res=httpReq.request(Method.GET);
			 Response res=httpReq.post("api/users");
			 res.getBody().prettyPrint();
		}
		}
	