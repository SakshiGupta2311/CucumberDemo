package restAssuredDemo;

import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojoFiles.ApiUpskillAuthResponse;

public class RestAPIUpskillBasicAuth {
	@Test
  public void oAuthDemo(){
		Response resp=RestAssured.given()
				.baseUri("http://rest-api.upskills.in/api/rest_admin/oauth2/token/client_credentials")
				.accept(ContentType.JSON)//.header()
				.header("Authorization","Basic ZGVtb19vYXV0aF9jbGllbnQ6ZGVtb19vYXV0aF9zZWNyZXQ=")
		.when()
			.post();
		
		ApiUpskillAuthResponse ApiUpskillAuthResponse=resp.as(ApiUpskillAuthResponse.class);
     //  String responsebody=resp.getBody().asString();
   //    System.out.println(responsebody);
		System.out.println("Success Code="+ApiUpskillAuthResponse.getSuccess());
	  
  }
}
