package restAssuredDemo;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

import io.restassured.http.Header;
public class SixthDemo {

		@Test
		public void restDemo() {
			System.out.println("Inside Rest");
			//File handling
			File jsonFile=new File("C:\\\\Users\\\\SakshiGupta\\\\eclipse-workspace\\\\Gupta\\\\src\\\\main\\\\java\\\\restAssuredDemo\\\\AuthPayLoad.json");
			////==================Approach 2====================
			Header acceptHeader = new Header("Content-Type","application/json");
	        
			RestAssured.given()
								.baseUri("https://restful-booker.herokuapp.com/auth")
								.header(acceptHeader)
//								.contentType(ContentType.JSON)
								.body(jsonFile)
						.when()
								.post()
						.then()
								.assertThat()
									.statusCode(200)
									.body("token.length()", Matchers.is(15));
			}
	}

