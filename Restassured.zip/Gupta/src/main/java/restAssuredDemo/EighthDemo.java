package restAssuredDemo;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pojoFiles.AuthPayLoad;
public class EighthDemo {

		        @Test
				public void restDemo() {
				System.out.println("Inside Rest");
				AuthPayLoad authObject=new AuthPayLoad("admin","password123");
				//1. Base URI
				RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
				//2. Request Specification
				Header acceptHeader = new Header("Content-Type","application/json");
		        RequestSpecification httpReq=RestAssured.given()
		        		       	     .log().all()   ///Logs Everything to console, = everything()
      		                         .log().body()///Logs only body
                                   	.log().cookies()
        	
      		                    .header(acceptHeader).body(authObject);
				Response res=httpReq.request(Method.POST);
				res.getBody().prettyPrint();
	}

}