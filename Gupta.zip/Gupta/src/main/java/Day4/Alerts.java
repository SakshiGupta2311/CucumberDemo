package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class Alerts {

		public static void main(String[] args) throws InterruptedException {
			// Launching edge
			System.setProperty("webdriver.edge.driver",
					"C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
			WebDriver wd = new EdgeDriver();
				wd.get("http://demo.automationtesting.in/Alerts.html");
				Thread.sleep(5000);
				wd.findElement(By.xpath("//*[@class='btn btn-danger']")).click();
				wd.switchTo().alert().accept();
				Thread.sleep(5000);
				wd.findElement(By.partialLinkText("Alert with OK & Cancel")).click();
				wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
				wd.switchTo().alert().accept();
				wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
				wd.switchTo().alert().dismiss();
				Thread.sleep(5000);
				wd.findElement(By.partialLinkText("Alert with Textbox")).click();
				wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
				wd.switchTo().alert().sendKeys("test");
				wd.switchTo().alert().accept();
				wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
				wd.switchTo().alert().accept();
				
				wd.close();
				
			}

		}