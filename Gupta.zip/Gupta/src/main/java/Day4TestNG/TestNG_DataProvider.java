package Day4TestNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNG_DataProvider {
	@Test(dataProvider="MyTestData")
	public void testMethod2(String sValue,int sNumb) {
		System.out.println("Inside My Test ng method testMethod 2 with Value:"+sValue +" and Number="+sNumb);
	}

	@Test()
	public void testMethod3() {
		System.out.println("Inside My Test ng method testMethod 3");
	}	

	@DataProvider (name = "MyTestData")
	public Object[][] dpMethod() {
	    return new Object [][] { {"First-Value",1}, {"Second-Value",2}};
	}

}