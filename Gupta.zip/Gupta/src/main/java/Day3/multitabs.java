package Day3;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class multitabs {

		public static void main(String[] args) throws InterruptedException {
			// Launching edge
			System.setProperty("webdriver.edge.driver",
					"C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
			WebDriver wd = new EdgeDriver();
			// Navigating to google
			wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
			wd.manage().window().maximize();
			Thread.sleep(5000);
			
	//		Set<String> tabs=wd.getWindowHandles();
	//		for(String eachTab:tabs) {
	//			System.out.println(eachTab);
		//	for(int i=0;i<tabs.size();i++) {
		//		System.out.println(tabs.get(i).getText());
	//			}
	//		}
			
			
			wd.findElement(By.xpath("//body")).sendKeys(Keys.CONTROL + "t");
			((JavascriptExecutor) wd).executeScript("window.open()");
			Set<String> tabs=wd.getWindowHandles();
			for(String eachTab:tabs)
			{
				System.out.println(eachTab);
				wd.switchTo().window(eachTab);
			}
			wd.get("https://www.google.com/");
			
			wd.close();
			
		}

	}