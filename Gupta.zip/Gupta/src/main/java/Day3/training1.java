package Day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class training1 {

	public static void main(String[] args) throws InterruptedException {
				//Launching Chrome
		System.setProperty("webdriver.edge.driver", "C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
		WebDriver wd=new EdgeDriver();
		//Navigating to google
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		// Extracting Navigated URL
		System.out.println("URL:" + wd.getCurrentUrl());
		// Extracting Title
		System.out.println("TITLE:" + wd.getTitle());
		wd.findElement(By.name("q")).sendKeys("Selenium is good"+Keys.ENTER);
		Thread.sleep(5000);
		//wd.findElement(By.name("btnK")).click();
		
		//print all links----------
		
		List<WebElement>  listLinks=wd.findElements(By.xpath("//a/h3"));
	//	List<WebElement>  listLinks=wd.findElements(By.xpath("//span/em"));
		for(int i=0;i<listLinks.size();i++) 
		{
			System.out.println(listLinks.get(i).getText());
//			listLinks.get(i).getAttribute("class")
		}
//			for(WebElement eachElement:listLinks) {
//				System.out.println(eachElement.getText());
//				listLinks.get(i).getAttribute("class")
//			}
		
		
		//Clicking on all two radio button-----------
		
		Thread.sleep(3000);
		wd.navigate().to("https://demos.jquerymobile.com/1.4.5/checkboxradio-radio/");
		List<WebElement>  listLinks2=wd.findElements(By.xpath("//label[text()='Two']"));
		for(WebElement eachElement:listLinks2) 
		{
		eachElement.click();
		
		}
		
		// Closing Chrome
		wd.close();


	}
}
