package Day3;

import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class table {

	public static void main(String[] args) throws InterruptedException {
		//Launching Chrome
		System.setProperty("webdriver.edge.driver", "C:\\Users\\SakshiGupta\\eclipse-workspace\\Gupta\\edgedriver_win64\\msedgedriver.exe");
		WebDriver wd=new EdgeDriver();
		wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		List<WebElement> weColData=wd.findElements(By.xpath("//table[@id='customers']//tr//td[2]"));
		for(int i=0;i<weColData.size();i++) 
		{
			System.out.println(weColData.get(i).getText());
		}
		
}
}
